<?php
/**
 * Canadian states
 */
$states['CA'] = array(
  'AB' => _x('Alberta', 'ui', 'memberpress'),
  'BC' => _x('British Columbia', 'ui', 'memberpress'),
  'MB' => _x('Manitoba', 'ui', 'memberpress'),
  'NB' => _x('New Brunswick', 'ui', 'memberpress'),
  'NL' => _x('Newfoundland', 'ui', 'memberpress'),
  'NT' => _x('Northwest Territories', 'ui', 'memberpress'),
  'NS' => _x('Nova Scotia', 'ui', 'memberpress'),
  'NU' => _x('Nunavut', 'ui', 'memberpress'),
  'ON' => _x('Ontario', 'ui', 'memberpress'),
  'PE' => _x('Prince Edward Island', 'ui', 'memberpress'),
  'QC' => _x('Quebec', 'ui', 'memberpress'),
  'SK' => _x('Saskatchewan', 'ui', 'memberpress'),
  'YT' => _x('Yukon Territory', 'ui', 'memberpress')
);

