<?php
if(!defined('ABSPATH')) { die('You are not allowed to call this page directly.'); }

MeprUtils::flush_rewrite_rules();

