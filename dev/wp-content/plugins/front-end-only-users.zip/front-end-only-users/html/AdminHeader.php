		<div class="wrap">
		<div class="Header"><h2><?php _e("Front End Only Users Settings", 'front-end-only-users') ?></h2></div>

		