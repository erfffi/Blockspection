jQuery(".ewd-feup-dis-input").click(function(){
		
}